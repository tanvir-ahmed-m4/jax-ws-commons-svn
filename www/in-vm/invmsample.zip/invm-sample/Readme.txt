* Ant based In-Vm sample
*Directory structure
    * src - All source code
    * lib - invm-transport.jar
    * webapp - deployment descriptor to deploy the web service endpoint on In-Vm transport
* Install Metro from https://metro.dev.java.net
* export METRO_HOME=c:/metro (or whereever you install Metro)
* To run
    - 'ant j2wsdl'
      Runs wsgen to generates wrapper classes and WSDL/XML schema files

    - 'ant client'
      Compile the wsdl, deploy the endpoint and invoke the endpoint 

