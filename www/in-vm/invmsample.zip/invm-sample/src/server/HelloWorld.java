package server;

import javax.jws.WebService;

/**
 * @author Vivek Pandey
 */
@WebService
public class HelloWorld {
    public String sayHello(String hello){
        return hello+" World";
    }
}
