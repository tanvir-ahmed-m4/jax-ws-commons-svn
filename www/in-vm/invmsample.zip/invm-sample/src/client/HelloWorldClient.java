package client;

import com.sun.xml.ws.transport.local.InVmServer;

import javax.xml.ws.BindingProvider;
import java.io.File;
import java.io.IOException;

/**
 * @author Vivek Pandey
 */
public class HelloWorldClient {
    private static InVmServer server;
    public static void main(String[] args) throws IOException {
        System.getProperties().put("jaxp.debug", true);
        if(args.length == 0){
            System.out.println("Usage: client.HelloWorldClient <Path to WEB-INF location>");
            return;
        }

        deploy(new File(args[0]));
        HelloWorldService service = new HelloWorldService();
        HelloWorld proxy = service.getHelloWorldPort();

        //point to the locally deployed HelloWorld service
        ((BindingProvider)proxy).getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, "in-vm://helloworld/HelloWorldPort");
        System.out.println(proxy.sayHello("hello"));
        undeploy();
    }

    private static void deploy(File explodedWar) throws IOException {
        server = new InVmServer("helloworld", explodedWar);
    }

    private static void undeploy(){
        server.undeploy();
    }
}
